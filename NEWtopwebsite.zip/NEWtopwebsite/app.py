from flask import Flask, render_template, request
import db



# Создаем объект нашего приложения
app = Flask(__name__)
app = Flask(__name__, static_folder='static')

@app.route('/')
def main():
    '''Функция возвращает html документ
    когда мы обращаемся на главную страницу ('/') '''
    return render_template('main.html')

@app.route('/buy_menu')
def buy_menu():
    return render_template('buy_menu.html')

@app.route('/get_contact', methods=['GET', 'POST'])
def save_contact():
    if request.method == 'POST':
        name = request.form.get('surname')
        phone = request.form.get('number_phone')
        db.insert_contact(name, phone )
    return render_template('payment.html')

@app.route('/payment')
def payment():
    return render_template('payment.html')


if __name__ == "__main__":
    app.run()