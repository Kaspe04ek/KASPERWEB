import sqlite3
from random import randint

def create():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS contacts (
        id INTEGER PRIMARY KEY,
        surname VARCHAR,
        number_phone VARCHAR)''')
    conn.commit()
    cursor.close()
    conn.close()


def clear_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''DROP TABLE IF EXISTS contacts''')
    conn.commit()
    cursor.close()
    conn.close()


def insert_contact(name, phone):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO contacts (surname, number_phone) VALUES (?, ? )''', [name, phone])
    conn.commit()
    cursor.close()
    conn.close()